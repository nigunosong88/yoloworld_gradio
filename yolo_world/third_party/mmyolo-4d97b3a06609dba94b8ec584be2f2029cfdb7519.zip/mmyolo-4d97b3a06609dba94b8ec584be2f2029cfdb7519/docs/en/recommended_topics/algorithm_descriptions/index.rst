Algorithm principles and implementation
******************************************

.. toctree::
   :maxdepth: 1

   yolov5_description.md
   yolov8_description.md
   rtmdet_description.md
