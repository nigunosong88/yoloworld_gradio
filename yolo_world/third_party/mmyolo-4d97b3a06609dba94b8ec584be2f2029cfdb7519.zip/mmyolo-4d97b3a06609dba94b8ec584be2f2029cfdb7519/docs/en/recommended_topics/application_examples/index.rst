MMYOLO application examples
********************

.. toctree::
   :maxdepth: 1

   ionogram_detection.md
